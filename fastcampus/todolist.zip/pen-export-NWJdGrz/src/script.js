Vue.component('my-todo-item',{
  props:['todo'],
  template: `<li>
      <!--   양방향 연결    -->
      <input type="checkbox" v-model="todo.done"> 
      <span v-bind:class="{done:todo.done}">{{ todo.title }}</span>
    </li>`
})

new Vue({
  el:"#app",
  data:{
    todos: [
      {
       id: '1',
       title:'아침 먹기',
       done: true,
      },
      {
       id: '2',
       title:'점심 먹기',
       done: true,
      },
      {
       id: '3',
       title:'저녁 먹기',
       done: false,
      },
      {
       id: '4',
       title:'간식 먹기',
       done: false,
      },
      {
       id: '5',
       title:'야식 먹기',
       done: false,
      },
    ],
   todos2: [
      {
       id: '11',
       title:'연필 사기',
       done: true,
      },
      {
       id: '12',
       title:'지우개 사기',
       done: false,
      },
      {
       id: '13',
       title:'필통 사기',
       done: false,
      },
      {
       id: '14',
       title:'안경 사기',
       done: false,
      },
      {
       id: '15',
       title:'컵사기',
       done: true,
      },
    ],
  }
})