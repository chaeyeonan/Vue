const vm = new Vue({
  el: "#app",
  data: {
    toggle: false,
    message:'', // 양방향 연결로 input에 따라 message data 갱신 
  },
  methods: {
    toggleElement() {
      this.toggle = !this.toggle;
    }
  }
});